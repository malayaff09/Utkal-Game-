const express = require('express');
const app = express();
const PORT = 3000;

const result = {
  period: "20250711100010800",
  number: 6,
  color: "Red",
  size: "Big"
};

app.get('/api/latest-result', (req, res) => {
  res.json(result);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
